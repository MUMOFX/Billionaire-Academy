MUMOFX Billionaire Academy — Ready Project

FILES
- index.html
- logo.jpeg              = uploaded MUMOFX logo
- bots-hero.png          = uploaded KINGBOT robot image
- certificate.jpeg       = uploaded certificate design

OPTIONAL
- academy.pdf            = put your academy PDF in this folder using exactly this filename.
  The Download Academy PDF button in index.html will then work.

HOW TO RUN
1. Keep all files in the same folder.
2. Open index.html in a browser.
3. For best results, use a simple local server (for example VS Code Live Server).

WHATSAPP
+254 180 225832
https://wa.me/254180225832

NOTE
The BTC price widget uses a public API. Other displayed market values are interface/demo values until a real market-data provider is connected.
